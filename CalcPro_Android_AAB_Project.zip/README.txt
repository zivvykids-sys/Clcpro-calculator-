CalcPro Android AAB Project

1. Open this project in Android Studio.
2. Let Gradle sync/download the Android Gradle Plugin.
3. Test with Run on an Android device/emulator.
4. For Play Store:
   Build > Generate Signed Bundle / APK > Android App Bundle
5. Create/select a release keystore and keep the keystore/password safe.
6. Build the release .aab.
7. Upload the signed AAB to Google Play Console.

Application ID: com.calcpro.app
Version: 1.0 (versionCode 1)

The supplied PWA files are bundled locally in app/src/main/assets, so the app does not depend on the Vercel URL for its main page.
